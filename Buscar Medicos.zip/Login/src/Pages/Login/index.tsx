import ShowPassword from "../../Components/Icones/showPassword";
import "./login.css";
import { useRef, useState } from "react";

const Login = () => {
  const senhaInputRef = useRef<HTMLInputElement>(null);
  const [emailValue, setEmailValue] = useState("");
  const [senhaValue, setSenhaValue] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmailValue(e.target.value);
  };

  const handleSenhaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSenhaValue(e.target.value);
  };

  const isEmailFilled = emailValue !== "";
  const isSenhaFilled = senhaValue !== "";

  const emailInputStyle = {
    borderColor: isEmailFilled ? "#00C247" : "",
  };

  const senhaInputStyle = {
    borderColor: isSenhaFilled ? "#00C247" : "",
  };

  return (
    <div className="fundo">
      <div className="container">
        <div className="seja-bem-vindo">Seja bem-vindo!</div>
        <div className="realize-seu-login">Realize seu Login</div>

        <div className={`inputfield-with-label ${isEmailFilled ? "filled" : ""}`}>
          <label
            className="fundoBranco"
            htmlFor="email"
            style={{ color: isEmailFilled ? "#00C247" : "" }}
          >
            E-mail
          </label>
          <input
            id="email"
            className={`email-input ${isEmailFilled ? "filled" : ""}`}
            type="text"
            value={emailValue}
            onChange={handleEmailChange}
            style={emailInputStyle}
          />
        </div>

        <div
          className={`inputfield-with-label1 ${isSenhaFilled ? "filled" : ""}`}
        >
          <label
            className="fundoBranco"
            htmlFor="senha"
            style={{ color: isSenhaFilled ? "#00C247" : "" }}
          >
            Senha
          </label>
          <div className="senha-input-container">
            <input
              id="senha"
              className={`senha-input ${isSenhaFilled ? "filled" : ""}`}
              type={rememberMe ? "text" : "password"}
              placeholder="Insira sua senha"
              value={senhaValue}
              onChange={handleSenhaChange}
              ref={senhaInputRef}
              style={senhaInputStyle}
            />
            <ShowPassword inputRef={senhaInputRef} />
          </div>
        </div>

        <div className="flex">
          <div className="lembrar-me">
            <label className="lembrar-me">
              <input
                className="checkBox"
                type="checkbox"
                checked={rememberMe}
                onChange={() => setRememberMe(!rememberMe)}
              />
              Lembrar-me
            </label>
          </div>
          <div className="esqueci-minha-senha">Esqueci minha senha</div>
        </div>

        <div>
          <button className="botaoEntrar">Entrar</button>
        </div>
      </div>
    </div>
  );
};

export default Login;