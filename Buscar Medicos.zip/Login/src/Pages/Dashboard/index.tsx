import React from 'react';
import './dashboard.css'
import Menu from '../../Components/Menu';
import MenuSuperior from "../../Components/MenuSuperior"

const App: React.FC = () => {
  return (
    <div className="App">
      <Menu />

      <div className="content">
        <MenuSuperior />
      </div>
    </div>
  );
};

export default App;
