import React from 'react';
import './menuSuperior.css'
import AvatarTopo from '../Icones/avatarTopo';
import MenuBarras from '../Icones/menuBarras';

const MyComponent: React.FC = () => {
  return (
    <div className='containerHorizontal'>
      <div>
        <MenuBarras />
      </div>
      <div className='avatarTopo'>
        <AvatarTopo />
      </div>
    </div>
  );
};

export default MyComponent;
